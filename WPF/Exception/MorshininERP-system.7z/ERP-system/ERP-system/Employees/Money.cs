﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    public class Money
    {

        private int salary;
        public int Salary
        {
            get { return salary; }
            set { salary = value; }
        }
        private string month;
        public string Month
        {
            get { return month; }
            set { month = value; }
        }
    }
}
